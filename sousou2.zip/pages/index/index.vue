<template>
	<view class="index">
		<view class="header">
			<view class="header-top"></view>
			<view class="search-style">
				<uni-icons size="40" type="loop" @click="showset" />
				<uni-search-bar
					class="search-layout"
					v-model="search"
					placeholder="请输入搜索关键词"
					bgColor="#EEEEEE"
					cancelButton="none"
					@confirm="searchEvent"
					@clear="searchClearEvent"
					borderColor="#000000"
					style="width: 70%"
				></uni-search-bar>
				<view class="first-text" @click="searchEvent">搜索</view>
			</view>
			<scroll-view style="white-space: nowrap;" scroll-x="true" show-scrollbar="false" scroll-left="120">
				<view style="display: flex;flex-direction: row;justify-content: flex-start;margin-top: 5px;margin-bottom: 5px;">
					<view class="second-text" style="color: #000000;margin-right: 10px;" @click="getsearch(item)" v-for="(item, index) in suglists" :key="index">
							{{ item }}
					</view>
				</view>
			</scroll-view>
		</view>
		<view class="body">
			<swiper style="height: 20vh;" autoplay="true" circular="true" interval="3000" duration="1000" @change="changeCurrent">
				<swiper-item v-for="(item, index) in lunbolist" :key="index">
					<view style="display: flex; flex-direction: column">
						<image style="height: 20vh; width: 100%;" :src="item.pic" mode="aspectFill" @click="navsearch(item.title)"></image>
						<view
							class="first-text"
							style="
							margin-top: -25px;
							z-index: 2;
							display: flex;
							color: #fff;
							justify-content: center;
							background-color: rgba(0, 0, 0, 0.4);
              "
						>
							{{ item.title }}
						</view>
					</view>
				</swiper-item>
			</swiper>
			<scroll-view style="white-space: nowrap" scroll-x="true" show-scrollbar="false" scroll-left="120">
				<view
					style="
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            margin-top: 10rpx;
          "
				>
				<view v-for="(item, index) in settings" :key="index">
					<!-- <view v-for="(item, index) in settings" :key="index" v-if="showsetting"> -->
						<view
							@click="navpages(index)"
							style="
                height: 100rpx;
                width: 100rpx;
                border-radius: 50%;
                background-color: #f0f0f0;
                display: flex;
                justify-content: center;
                align-items: center;
              "
						>
							<view class="first-text">{{ item }}</view>
						</view>
					</view>
				</view>
			</scroll-view>
			<view class="data-new">
				<view class="data-header">
					<view class="first-text">追剧</view>
					<view class="first-text" @click="navclass(0)">更多</view>
				</view>
				<scroll-view style="white-space: nowrap" scroll-x="true" show-scrollbar="false" scroll-left="120">
					<view style="display: flex; flex-direction: row; flex-wrap: nowrap">
						<view style="display: flex; flex-direction: column; margin-right: 20rpx" v-for="(item, index) in tvlist" :key="index">
							<image :src="item.pic" mode="aspectFill" style="width: 115px; height: 160px;border-radius: 5%;" @click="navsearch(item.title)"></image>
							<view
								class="second-text"
								style="
								  margin-top: -22px;
								  z-index: 2;
								  color: #fff;
								  background-color: rgba(0, 0, 0, 0.4);
								"
							>
								{{ item.state }}
							</view>
							<view class="second-text" style="color: #000000;display: flex;flex-wrap: wrap;">{{ item.title.slice(0, 7) }}</view>
						</view>
					</view>
				</scroll-view>
			</view>
			<view class="data-new">
				<view class="data-header">
					<view class="first-text">电影</view>
					<view class="first-text" @click="navclass(1)">更多</view>
				</view>
				<scroll-view style="white-space: nowrap" scroll-x="true" show-scrollbar="false" scroll-left="120">
					<view style="display: flex; flex-direction: row; flex-wrap: nowrap">
						<view style="display: flex; flex-direction: column; margin-right: 20rpx" v-for="(item, index) in filmlist" :key="index">
							<image :src="item.pic" mode="aspectFill" style="width: 115px; height: 160px;border-radius: 5%;" @click="navsearch(item.title)"></image>
							<view
								class="second-text"
								style="
                 margin-top: -22px;
                 z-index: 2;
               color: #fff;
               background-color: rgba(0, 0, 0, 0.4);
               "
							>
								评分:{{ item.state.slice(0, 10) }}
							</view>
							<view class="second-text" style="color: #000000;display: flex;flex-wrap: wrap;">{{ item.title.slice(0, 7) }}</view>
						</view>
					</view>
				</scroll-view>
			</view>
			<view class="data-new">
				<view class="data-header">
					<view class="first-text">动漫</view>
					<view class="first-text" @click="navclass(2)">更多</view>
				</view>
				<scroll-view style="white-space: nowrap" scroll-x="true" show-scrollbar="false" scroll-left="120">
					<view style="display: flex; flex-direction: row; flex-wrap: nowrap">
						<view style="display: flex; flex-direction: column; margin-right: 20rpx" v-for="(item, index) in cartoonlist" :key="index">
							<image :src="item.pic" mode="aspectFill" style="width: 115px; height: 160px;border-radius: 5%;" @click="navsearch(item.title)"></image>

							<view
								class="second-text"
								style="
                 margin-top: -22px;
                 z-index: 2;
                color: #fff;
                background-color: rgba(0, 0, 0, 0.4);
               "
							>
								{{ item.state.slice(0, 10) }}
							</view>
							<view class="second-text" style="color: #000000;display: flex;flex-wrap: wrap;">{{ item.title.slice(0, 7) }}</view>
						</view>
					</view>
				</scroll-view>
			</view>
			<view class="data-new">
				<view class="data-header">
					<view class="first-text">综艺</view>
					<view class="first-text" @click="navclass(3)">更多</view>
				</view>
				<scroll-view style="white-space: nowrap" scroll-x="true" show-scrollbar="false" scroll-left="120">
					<view style="display: flex; flex-direction: row; flex-wrap: nowrap">
						<view style="display: flex; flex-direction: column; margin-right: 20rpx" v-for="(item, index) in varietylist" :key="index">
							<image :src="item.pic" mode="aspectFill" style="width: 115px; height: 160px;border-radius: 5%;" @click="navsearch(item.title)"></image>
							<view
								class="second-text"
								style="
                 margin-top: -22px;
                 z-index: 2;
                color: #fff;
                background-color: rgba(0, 0, 0, 0.4);
               "
							>
								{{ item.state.slice(0, 10) }}
							</view>
							<view class="second-text" style="color: #000000;display: flex;flex-wrap: wrap;">{{ item.title.slice(0, 7) }}</view>
						</view>
					</view>
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
import http from '../../utils/http.js';
import db from '../../utils/database.js';
import uniIcons from '@/components/uni-ui/uni-icons/components/uni-icons/uni-icons.vue';
import uniSearchBar from '@/components/uni-ui/uni-search-bar/components/uni-search-bar/uni-search-bar.vue';
import uniCard from '@/components/uni-ui/uni-card/components/uni-card/uni-card.vue';
export default {
	components: { uniIcons, uniSearchBar,uniCard},
	data() {
		return {
			lunbolist: [],
			search: '',
			current: 0,
			settings: ['站源', '历史', '直播', '下载', '设置'],
			showsetting: false,
			tvlist: [],
			cartoonlist: [],
			filmlist: [],
			varietylist: [],
			suglists:[]
		};
	},
	watch: {
		search(newurl, oldurl) {
		this.getsuggestion()
		}
	},
	onLoad() {
		
		this.getlunbolist();
		this.getbodydata();
	},
	methods: {
		async getsearch(item){
			this.search=item;
		},
		async getsuggestion(){
			this.suglists=await http.getsuggestion(this.search)
		},
		async navclass(num){

	        uni.navigateTo({ url: `/pages/class/class?num=${num}` });
			
		},
		async searchEvent() {
			if (this.search === '') {
				return false;
			} else {
				this.navsearch(this.search);
			}
		},
		async searchClearEvent() {
			this.search = '';
		},
		async navsearch(key) {
			this.search = key;
			uni.navigateTo({ url: `/pages/search/search?search=${this.search}` });
		},
		navpages(index) {
			if (this.settings[index] == '站源') {
				uni.navigateTo({ url: `/pages/site/site` });
			}
			// console.log(this.settings[index])
			if (this.settings[index] == '历史') {
				// console.log(111)
				uni.navigateTo({ url: `/pages/history/history` });
			}
			if (this.settings[index] == '设置') {
				// console.log(111)
				uni.navigateTo({ url: `/pages/setting/setting` });
			}
			if (this.settings[index] == '直播') {
				// console.log(111)
				uni.navigateTo({ url: `/pages/live/live` });
			}
			if (this.settings[index] == '下载') {
				// console.log(111)
				uni.navigateTo({ url: `/pages/download/download` });
			}
		},
		changeCurrent(e) {
			this.current = e.detail.current;
		},
		showset() {
			// this.showsetting = !this.showsetting;
			// this.lunbolist=[];
			// this.tvlist=[]
			// this.filmlist=[]
			// this.cartoonlist=[]
			// this.varietylist=[]
			// this.getlunbolist();
			// this.getbodydata();
			let screenrotate = uni.getStorageSync("screenrotate");
			screenrotate=!screenrotate;
			uni.setStorageSync('screenrotate', screenrotate);
			db.rotatescreen()
		},
		async getlunbolist() {
			let html = await http.get('https://m.v.qq.com');

			let rangeres = await http.matchOnce('重磅热播([\\s\\S]*?)猜你喜欢', html);
			if (rangeres.flag) {
				let listres = await http.matchAll('class="item_content"([\\s\\S]*?)</div></a>', rangeres.data);
				if (listres.flag) {
					for (let listr of listres.data) {
						let titleres = await http.matchOnce('div class="item_title needsclick">([\\s\\S]*?)</div>', listr);
						let picres = await http.matchOnce('<img dsrc="([\\s\\S]*?)" lazyLoad=', listr);

						if (titleres.flag && picres.flag) {
							this.lunbolist.push({
								pic: picres.data,
								title: titleres.data.trim()
							});
						}
					}
				} else {
					uni.showToast({
						title: '轮播图获取失败！',
						duration: 2000,
						icon: 'error'
					});
				}
			} else {
				uni.showToast({
					title: '轮播图获取失败！',
					duration: 2000,
					icon: 'error'
				});
			}
		},
		async gethtmldata(url, site) {
			let searchLists = [];
			let header = {
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36'
			};
			let html = await http.get(url, header);
			let rangeres = await http.matchOnce(site.search_range, html);
			// console.log(rangeres.data);
			if (rangeres.flag) {
				let titleres = await http.matchAll(site.search_list_name, rangeres.data);
				let picres = await http.matchAll(site.search_list_src, rangeres.data);
				// console.log(picres.data)
				let stateres = await http.matchAll(site.search_list_state, rangeres.data);
				// console.log(stateres.data)
				if (titleres.flag && picres.flag) {
					for (let i = 0; i < titleres.data.length; i++) {
						if (picres.data[i] && picres.data[i].indexOf('//') == -1) {
							picres.data[i] = [site.pic_url, picres.data[i]].join('');
						}
						if (picres.data[i] && titleres.data[i]) {
							searchLists.push({
								pic: picres.data[i],
								title: titleres.data[i],
								state: stateres.data[i]
							});
						}
					}
					return {
						flag: true,
						data: searchLists,
						msg: '获取完成'
					};
				} else {
					return {
						flag: false,
						data: 'error!',
						msg: '获取失败'
					};
				}
			} else {
				return {
					flag: false,
					data: 'error!',
					msg: '获取失败'
				};
			}
		},
		async getbodydata() {
			let cartoonsite = {
				pic_url: '',
				search_range: '新番周更表([\\s\\S]*?)lz_next',
				search_list_name: '<img loading="lazy" class="figure_pic".*?src=".*?" alt="([\\s\\S]*?)" onerror=',
				search_list_src: '<img loading="lazy" class="figure_pic".*?src="([\\s\\S]*?)" alt=".*?" onerror="picerr',
				search_list_state: '<div class="figure_caption">([\\s\\S]*?)</div>'
			};
			let cartoonres = await this.gethtmldata('https://v.qq.com/channel/cartoon', cartoonsite);
			// console.log(cartoonres.data)
			if (cartoonres.flag) {
				this.cartoonlist = cartoonres.data;
			}
			let tvsite = {
				pic_url: '',
				search_range: '热剧精选([\\s\\S]*?)热点短视频',
				search_list_name: '<img loading="lazy" class="figure_pic".*?src=".*?" alt="([\\s\\S]*?)" onerror="picerr',
				search_list_src: '<img loading="lazy" class="figure_pic".*?src="([\\s\\S]*?)" alt=.*?onerror="picerr',
				search_list_state: '<div class="figure_caption">([\\s\\S]*?)</div>'
			};
			let tvres = await this.gethtmldata('https://v.qq.com/channel/tv', tvsite);
			if (tvres.flag) {
				this.tvlist = tvres.data;
			}
			let filmsite = {
				pic_url: '',
				search_range: '首播影院([\\s\\S]*?)自制电影',
				search_list_name: '<img loading="lazy" class="figure_pic".*?src=".*?" alt="([\\s\\S]*?)" onerror="picerr',
				search_list_src: '<img loading="lazy" class="figure_pic".*?src="([\\s\\S]*?)" alt=.*?onerror="picerr',
				search_list_state: '<div class="figure_score">([\\s\\S]*?)</div>'
			};
			let filmres = await this.gethtmldata('https://v.qq.com/channel/movie', filmsite);
			if (filmres.flag) {
				this.filmlist = filmres.data;
			}
			let varietysite = {
				pic_url: '',
				search_range: '热播周榜([\\s\\S]*?)mod_row_box mod_row_box_special mod_row_box_ad',
				search_list_name: '<img loading="lazy" class="figure_pic".*?src=".*?" alt="([\\s\\S]*?)" onerror="picerr',
				search_list_src: '<img loading="lazy" class="figure_pic".*?src="([\\s\\S]*?)" alt=.*?onerror="picerr',
				search_list_state: '<div class="figure_caption">([\\s\\S]*?)</div>'
			};
			let varietyres = await this.gethtmldata('https://v.qq.com/channel/variety', varietysite);
			if (varietyres.flag) {
				this.varietylist = varietyres.data;
			}
		}
	}
};
</script>

<style lang="scss">
.data-new {
}
.data-header {
	display: flex;
	flex-direction: row;
	justify-content: space-between;
}
</style>
