import ajax from './ajax.js'
import db from './database'
const http = {
	// 获取搜索列表
	async getSearchList(site, searchKey) {
		try {
			const searchLists = []
			let gethtml = await ajax.get(site.search_href.replace("searchKey", searchKey), {
				timeout: 5000
			});
			let html = gethtml.data;
			if (typeof html != "string") {
				html = JSON.stringify(html);
			}
			let re = new RegExp(site.search_range, 'g')
			let t;
			let rangeResults = [];
			while ((t = re.exec(html)) != null) {
				rangeResults.push(t[1]);
			};
			re = new RegExp(site.search_list_name, 'g')
			let nameResults = [];
			while ((t = re.exec(rangeResults[0])) != null) {
				nameResults.push(t[1].trim());
			};
			let picResults = [];
			re = new RegExp(site.search_list_src, 'g');
			while ((t = re.exec(rangeResults[0])) != null) {
				if (t[1].indexOf('http') == 0) {
					picResults.push(t[1].replace(new RegExp("\\\\", "g"), ""));
				} else {
					let httpurl = [site.pic_url, t[1]].join("")
					picResults.push(httpurl.replace(new RegExp("\\\\", "g"), ""));
				}
			};
			// console.log(nameResults)
			let hrefResults = [];
			re = new RegExp(site.search_list_href, 'g');
			while ((t = re.exec(rangeResults[0])) != null) {
				if (t[1].indexOf('http') == 0) {
					hrefResults.push(t[1].replace(new RegExp("\\\\", "g"), ""));
				} else {
					let httpurl = [site.search_url, String(t[1])].join("")
					hrefResults.push(httpurl.replace(new RegExp("\\\\", "g"), ""));
				}
			};
			// console.log(hrefResults)
			let stateResults = [];
			re = new RegExp(site.search_list_state, 'g');
			while ((t = re.exec(rangeResults[0])) != null) {
				stateResults.push(t[1].trim());
			};
			for (let j = 0; j < nameResults.length; j++) {
				let pt = [];
				pt.push(nameResults[j]);
				pt.push(hrefResults[j]);
				pt.push(picResults[j]);
				pt.push(stateResults[j]);
				searchLists.push(pt);
			}
			const lastLists = [site.name, searchLists]
			return {
				flag: true,
				data: lastLists,
				msg: '搜索完成'
			}
		} catch (err) {
			return {
				flag: false,
				data: err,
				msg: '搜索失败'
			}
		}
	},
	// 获取首页列表
	async getindexlist(site, href) {
		try {
			if (site.id == 'XT') {
				let indexlists = [];
				let gethtml = await ajax.get(href, {
					timeout: 5000
				});
				let html = gethtml.data;
				if (typeof html != "string") {
					html = JSON.stringify(html);
				}
				let re = new RegExp(site.class_range, 'g')
				let t;
				let rangeResults = [];
				while ((t = re.exec(html)) != null) {
					rangeResults.push(t[1]);
				};
				re = new RegExp(site.class_list_name, 'g')
				let nameResults = [];
				while ((t = re.exec(rangeResults[0])) != null) {
					nameResults.push(t[1].trim());
				};
				let picResults = [];
				re = new RegExp(site.class_list_src, 'g');
				while ((t = re.exec(rangeResults[0])) != null) {
					if (t[1].indexOf('http') == 0) {
						picResults.push(t[1].replace(new RegExp("\\\\", "g"), ""));
					} else {
						let httpurl = [site.pic_url, t[1]].join("")
						picResults.push(httpurl.replace(new RegExp("\\\\", "g"), ""));
					}
				};
				// console.log(nameResults)
				let hrefResults = [];
				re = new RegExp(site.class_list_href, 'g');
				while ((t = re.exec(rangeResults[0])) != null) {
					if (t[1].indexOf('http') == 0) {
						hrefResults.push(t[1].replace(new RegExp("\\\\", "g"), ""));
					} else {
						let httpurl = [site.search_url, String(t[1])].join("")
						hrefResults.push(httpurl.replace(new RegExp("\\\\", "g"), ""));
					}
				};
				// console.log(hrefResults)
				let stateResults = [];
				re = new RegExp(site.class_list_state, 'g');
				while ((t = re.exec(rangeResults[0])) != null) {
					stateResults.push(t[1].trim());
				};
				for (let j = 0; j < nameResults.length; j++) {
					let pt = [];
					pt.push(nameResults[j]);
					pt.push(hrefResults[j]);
					pt.push(picResults[j]);
					pt.push(stateResults[j]);
					indexlists.push(pt);
					// console.log(pt)
				}
				const lastLists = [site.name, indexlists]
				// console.log(lastLists)
				return {
					flag: true,
					data: lastLists,
					msg: '获取完成'
				}
			} else {
				let indexlists = [];
				let jsonStringt = await ajax.get(href, {
					timeout: 5000
				});
				let rangeslice = site.class_range.split('.');
				var range_search = jsonStringt.data;
				for (let slice of rangeslice) {

					range_search = range_search[slice]
				}
				for (let jsondata of range_search) {

					let pt = [];
					pt.push(jsondata[site.class_list_name]);
					pt.push(site.search_url + String(jsondata[site.class_list_href]));
					pt.push(jsondata[site.class_list_src]);
					pt.push(jsondata[site.class_list_state]);
					indexlists.push(pt);
				}
				const lastLists = [site.name, indexlists];
				return {
					flag: true,
					data: lastLists,
					msg: '获取完成'
				}
			}

		} catch (err) {
			return {
				flag: false,
				data: err,
				msg: '获取失败'
			}
		}
	},
	// 通过 json url 导入视频源
	async siteUrl(jsonUrl) {
		try {
			const res = await ajax.get(jsonUrl, {
				timeout: 5000
			});
			return res.data
		} catch (err) {
			return err
		}
	},
	// 通过 json url 导入视频源
	async site(jsonUrl) {
		try {
			if (jsonUrl.startsWith("http")) {
				let urlslices = jsonUrl.split('&&&&');
				let urlList = uni.getStorageSync('urlNotive');
				let urldata = {
					name: urlslices[1],
					url: urlslices[0],
					isActive: true
				}
				const rre = await db.checkItemNotivre(urldata, urlList);
				if (rre.flag) {
					urlList.push(urldata);
					uni.setStorageSync('urlNotive', urlList)

				}
				const res = await ajax.get(urlslices[0], {
					timeout: 5000
				});
				return res.data
			}
			if (jsonUrl.startsWith("{")) {
				if (JSON.parse(jsonUrl).name != '') {
					return [JSON.parse(jsonUrl)]
				}
			}
			if (jsonUrl.startsWith("[")) {
				if (JSON.parse(jsonUrl)[0].name != '') {
					return JSON.parse(jsonUrl)
				}

			}



		} catch (err) {
			return err
		}
	},
	// 获取更新状态
	async getState(url, site) {
		try {
			let gethtml = await ajax.get(url, {
				timeout: 5000
			});
			let html = gethtml.data;
			let re = new RegExp(site.play_range, 'g')
			let t;
			let rangeResults = [];
			while ((t = re.exec(html)) != null) {
				rangeResults.push(t[1]);
			};
			re = new RegExp(site.play_state, 'g')
			let stateResults = [];
			while ((t = re.exec(rangeResults[0])) != null) {
				stateResults.push(t[1].trim());
			};
			return {
				flag: true,
				data: stateResults,
				msg: '状态更新完成'
			}
		} catch (err) {
			return {
				flag: false,
				data: err,
				msg: '状态获取失败'
			}
		}
	},
	// 爬剧集
	async getPlayData(url, site) {
		try {
			let gethtml = await ajax.get(url, {
				timeout: 5000
			});
			let html = gethtml.data;
			let re = new RegExp(site.play_range, 'g')
			let t;
			let rangeResults = [];
			while ((t = re.exec(html)) != null) {
				rangeResults.push(t[1]);
			};
			// console.log(rangeResults)
			re = new RegExp(site.name_tag_list, 'g')
			let nameTagRanges = [];
			while ((t = re.exec(rangeResults[0])) != null) {
				nameTagRanges.push(t[1]);
			};
			re = new RegExp(site.name_tag, 'g')
			let nameTags = [];
			while ((t = re.exec(nameTagRanges[0])) != null) {
				nameTags.push(t[1].trim());
			};
			re = new RegExp(site.play_list, 'g')
			const playLists = [];
			while ((t = re.exec(rangeResults[0])) != null) {
				playLists.push(t[1]);
			};
			// console.log(playLists)
			const playdatas = [];
			for (let j of playLists) {
				let tt;
				let re1 = new RegExp(site.play_list_name, 'g')
				const playListNames = [];
				while ((tt = re1.exec(j)) != null) {
					playListNames.push(tt[1].trim());
				};
				let re2 = new RegExp(site.play_list_href, 'g')
				const playListHrefs = [];
				while ((tt = re2.exec(j)) != null) {
					if (tt[1].indexOf('http') == 0) {
						playListHrefs.push(tt[1].replace(new RegExp("\\\\", "g"), ""));

					} else {
						let httpurl = [site.url, tt[1]].join("")
						playListHrefs.push(httpurl.replace(new RegExp("\\\\", "g"), ""));
					}
				};
				playdatas.push([playListNames, playListHrefs])
			}
			return {
				flag: true,
				data: [nameTags, playdatas],
				msg: '剧集加载成功'
			}
		} catch (err) {
			return {
				flag: false,
				data: err,
				msg: '剧集获取失败'
			}
		}
	},
	// app搜索
	async appSearch(site, searchKey) {
		searchKey = encodeURI(searchKey);
		let searchLists = []
		try {
			let jsonStringt = await ajax.get(site.search_href.replace("searchKey", searchKey), {
				timeout: 5000
			});
			let rangeslice = site.search_range.split('.');
			var range_search = jsonStringt.data;
			for (let slice of rangeslice) {

				range_search = range_search[slice]
			}
			for (let jsondata of range_search) {

				let pt = [];
				pt.push(jsondata[site.search_list_name]);
				pt.push(site.search_url + String(jsondata[site.search_list_href]));
				pt.push(jsondata[site.search_list_src]);
				pt.push(jsondata[site.search_list_state]);
				searchLists.push(pt);
			}
			const lastLists = [site.name, searchLists];
			return {
				flag: true,
				data: lastLists,
				msg: '搜索完成'
			}
		} catch (err) {
			return {
				flag: false,
				data: err,
				msg: '搜索失败'
			}
		}
	},
	//app爬剧集
	async appPlayData(url, site) {
		console.log(url)
		try {
			let getjson = await ajax.get(url, {
				timeout: 5000
			});
			let jsondata = getjson.data;
			let rangeslice = site.play_range.split('.');
			for (let slice of rangeslice) {
				jsondata = jsondata[slice]
			}
			let nameTags = [];
			let playdatas = [];
			let tempurl = "";
			for (let jsoninfo of jsondata) {
				nameTags.push(jsoninfo[site.name_tag]);

				let playjx = await this.panduanapi(site, jsoninfo)

				let playinfo = jsoninfo[site.play_list];

				const playListNames = [];
				const playListHrefs = [];
				for (let playslice of playinfo.split("#")) {
					let playsliceinfo = playslice.split("$");
					playListNames.push(playsliceinfo[0]);
					tempurl = playjx + playsliceinfo[1];
					if (tempurl.indexOf("url=") != -1 || tempurl.endsWith("m3u8") || tempurl.endsWith("mp4")) {
						playListHrefs.push(tempurl)
					} else {
						tempurl = site.extra_api + tempurl;
						playListHrefs.push(tempurl)
					}

				}
				playdatas.push([playListNames, playListHrefs]);
			}
			return {
				flag: true,
				data: [nameTags, playdatas],
				msg: '剧集加载成功'
			}





		} catch (err) {
			console.log(err)
			return {
				flag: false,
				data: err,
				msg: '剧集获取失败'
			}
		}
	},
	async getapi2(site, jsoninfo) {
		try {
			if (site.playapi2 && site.play_api2 != "") {
				let playjx = jsoninfo;
				let rangeslice = site.play_api2.split('.');
				for (let slice of rangeslice) {
					playjx = playjx[slice];

				}

				playjx = playjx.replace(/../g, ".")
				if (playjx.indexOf(",") != -1) {
					playjx = playjx.split(",")[0];
					if (playjx.indexOf("//") == -1) {
						playjx = "";
						return playjx
					} else {
						return playjx
					}
				} else {
					if (playjx.indexOf("//") == -1) {
						playjx = "";

						return playjx
					} else {
						return playjx
					}
				}


			} else {
				let playjx = "";

				return playjx
			}
		} catch (e) {
			let playjx = ''
			return playjx
		}

	},
	//判断api
	async panduanapi(site, jsoninfo) {
		try {
			if (site.play_api != "") {
				let playjx = jsoninfo;
				let rangeslice = site.play_api.split('.');
				for (let slice of rangeslice) {
					playjx = playjx[slice];

				}
				playjx = playjx.replace(/../g, ".")
				if (playjx.indexOf(",") != -1) {
					playjx = playjx.split(",")[0];
					if (playjx.indexOf("//") == -1) {
						playjx = await this.getapi2(site, jsoninfo);
						return playjx
					} else {
						return playjx
					}
				} else {
					if (playjx.indexOf("//") == -1) {
						playjx = await this.getapi2(site, jsoninfo);

						return playjx
					} else {
						return playjx
					}
				}


			} else {
				let playjx = "";

				return playjx
			}
		} catch (e) {
			let playjx = await this.getapi2(site, jsoninfo);
			return playjx
		}
	},

	//app 获取真实链接
	async appTureUrl(url) {
		console.log(url)
		if (url.indexOf("url=") === -1) {
			return url
		} else {
			let getjson = await ajax.get(url, {
				timeout: 5000
			});
			// console.log(getjson.data)
			if (getjson.data.url) {
				return getjson.data.url
			} else {
				return url
			}
		}
	},
	//app 获取更新
	async appstate(url, site) {
		try {
			let getjson = await ajax.get(url, {
				timeout: 5000
			});

			let jsondata = getjson.data;
			let rangeslice = site.play_state.split('.');
			for (let slice of rangeslice) {
				jsondata = jsondata[slice]
			}
			let stateResults = [jsondata];
			return {
				flag: true,
				data: stateResults,
				msg: '状态更新完成'
			}


		} catch (err) {
			return {
				flag: false,
				data: err,
				msg: '状态获取失败'
			}
		}
	},
	// 爬m3u8
	async getMUinfo(url) {
		let that = this
		uni.request({
			url: url,
			method: 'GET',
			success(res) {

				that.getDownUrl(res, url)
				return res
			},
			fail(res) {
				return -1
			}
		})
	},
	//deal res
	async getDownUrl(res, host) {
		var arr = res.data.split("\n");
		var data = []
		for (let i = 0; i < arr.length; i++) {
			if (arr[i] == '') {
				continue;
			}
			let line = arr[i].trim()
			if (line.startsWith('#EXT')) {
				continue;
			}
			if (line.startsWith('/')) {
				let url = host + line
			} else {
				let url = line
			}
			data.push(url)
		}

	}
}
export default http
