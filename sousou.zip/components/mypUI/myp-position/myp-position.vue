<template>
	<view :class="[fixed?'myp-position-fixed':'myp-position-absolute', 'myp-bg-'+bgType]" :style="mrBoxStyle">
		<slot></slot>
	</view>
</template>

<script>
	import {getHeight} from '../utils/system.js'
	
	export default {
		props: {
			/**
			 * 是否fixed定位
			 */
			fixed: {
				type: Boolean,
				default: false
			},
			/**
			 * 定位的位置
			 */
			pos: {
				type: String,
				default: 'bottom'
			},
			/**
			 * 定位的偏移量
			 */
			offset: {
				type: String,
				default: '0px'
			},
			/**
			 * 背景主题
			 */
			bgType: {
				type: String,
				default: 'none'
			},
			/**
			 * 外层样式
			 */
			boxStyle: {
				type: String,
				default: ''
			}
		},
		computed: {
			offsetPx() {
				return getHeight(this.offset)
			},
			mrBoxStyle() {
				return (this.pos === 'top' ? `top:${this.offsetPx}px;` : `bottom:${this.offsetPx}px;`) + this.boxStyle
			}
		}
	}
</script>

<style>
</style>
