export default {
	data() {
		return {
			wxsData: {}
		}
	}
}
