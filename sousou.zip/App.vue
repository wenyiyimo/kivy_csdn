<script>
import db from './utils/database.js';
export default {
	onLaunch: function() {
		plus.device.setWakelock(true);
		// 保持屏幕常亮
		uni.setKeepScreenOn({
			keepScreenOn: true
		});

		db.init('notive');
		db.init('site');
		db.init('history')
		let sWidth = uni.getSystemInfoSync().screenWidth;
		let sHeight = uni.getSystemInfoSync().screenHeight;
		if (sWidth > sHeight) {
			plus.screen.lockOrientation('landscape');
		} else {
			plus.screen.lockOrientation('portrait');
		}
	},
	onShow: function() {
		// console.log('App Show')
	},
	onHide: function() {
		// console.log('App Hide')
	}
};
</script>

<style>

</style>
