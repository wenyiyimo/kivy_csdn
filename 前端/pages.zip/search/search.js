<template>
	<list :id="parentListId" class="search" offset-accuracy="5" bounce="false" show-scrollbar="false">
		<cell>
			<view id="head">
			</view>
		</cell>
		<cell>
			<view class="main-content" :style="'height:' + pageHeight + 'px'">
				<view class="header">
					<image src="../../static/back.png" mode="aspectFit" class="header-img" @click="goBack()"></image>
					<uni-search-bar
						v-model="search"
						class="search-layout"
						:style="{ width: `${searchwidth}px` }"
						:value="search"
						placeholder="请输入搜索关键词"
						bgColor="#EEEEEE"
						cancelButton="none"
						@confirm="searchEvent"
						@clear="searchClearEvent"
						borderColor="#000000"
					></uni-search-bar>
					<text class="search-text" @click="searchEvent">搜索</text>
				</view>
				<list ref="sublist" offset-accuracy="5" bounce="false" show-scrollbar="false">
					<cell class="body">
					<view ref="tabitem" class="tab-item">
					<view class="tab-data" v-for="(item, index) in nameLists" :key="index">
						<text class="item-title" :class="[current == index ? 'item-title-active' : '']" :ripple="true" @click="tabSearch(index)">{{ item.slice(0, 2) }}</text>
						
						
					</view>
					</view>
					<list offset-accuracy="5" show-scrollbar="false">
					<cell class="data-item">
						<view id="detail-item" class="detail-item" v-for="(item, index) in detailLists" :key="index">
							<view class="out-item">
								<view class="tui-list-item" @click="detailButton(item)">
									<image :src="item[2]" mode="aspectFit" class="item-img"></image>
									<view class="item-box">
										<text class="item-title">{{ item[0] }}</text>
										<text class="item-name">来源：{{ nameLists[searchNum] }}</text>
										<text class="item-state">状态：{{ item[3] }}</text>
									</view>
								</view>
							</view>
						</view>
					</cell>
				
					</list>
					</cell>
					
				</list>
				
			</view>
		</cell>
		
	</list>
</template>

<script>
import db from '../../utils/database.js';
import http from '../../utils/request.js';

const dom = weex.requireModule('dom')
  

export default {
	data() {
		return {
			searchwidth: 200,
			siteLists: [],
			nameLists: [],
			search: '',
			fixedstate:"null",
			current: 0,
			searchLists: [],
			detailLists: [],
			searchNum: 0,
			fullControlsWidth: null,
			fullControlsHeigt: null,
			pageHeight: 300,
			parentListId: "parentListId",
		    
		};
	},
	created() {
		this.fullControlsHeigt = uni.getSystemInfoSync().screenHeight;
		this.fullControlsWidth = uni.getSystemInfoSync().screenWidth + 1;
		if (this.fullControlsWidth > this.fullControlsHeigt) {
			this.searchwidth = (this.fullControlsWidth * 3) / 4;
	
		} else {
			this.searchwidth = (this.fullControlsWidth * 2) / 3;
		}
	},
	onReady() {
		this.pageHeight = uni.getSystemInfoSync().windowHeight -40;

		uni.createSelectorQuery().in(this).select('#head').boundingClientRect().exec(rect => {
			this.$refs.sublist.setSpecialEffects({
				id: this.parentListId,
				headerHeight: rect[0].height
			});
		});
		// let that=this
		// setTimeout(function(){
			
		// 	const result = dom.getComponentRect(that.$refs.tabitem, option => {
		// 		console.log('getComponentRect:', option)
		// 	})
			
			
		// },5000)
	},
	
	methods: {
		
		
		
		async getNameLists() {
			const res = await db.getAll('site');
			if (res.flag) {
				for (let i of res.data) {
					if (i.isActive) {
						this.nameLists.push(i.name);
						this.siteLists.push(i);
					}
				}
				this.searchEvent();
			} else {
				this.$refs.uToast.show({ title: '读取视频源出错', type: 'warning', duration: '2300' });
				return false;
			}
		},
		async goBack() {
			// this.$router.go(-1);

			uni.redirectTo({
				url: `/pages/index/index`
			});
		},

		async searchEvent() {
			if (this.search === '') {
				return false;
			} else {
				this.searchLists = [];
				this.detailLists = [];
				this.searchNum = 0;
				this.current = 0;
				let siteName = this.siteLists[this.searchNum].id;
				if (siteName == 'XT') {
					const st = await http.getSearchList(this.siteLists[this.searchNum], this.search);
					this.searchLists.push(st.data);
					this.detailLists = st.data[1];
			
					
				}
				if (siteName == 'APP') {
					const st = await http.appSearch(this.siteLists[this.searchNum], this.search);
					this.searchLists.push(st.data);
					this.detailLists = st.data[1];
					
				}
			}
		},
		async searchClearEvent() {
			this.search = '';
		},
		async tabSearch(index) {
			this.searchNum = index;
			this.current = index;
			this.detailLists = [];
			let flag = false;
			for (let i of this.searchLists) {
				if (i[0] === this.nameLists[this.searchNum]) {
					this.detailLists = i[1];
					
					flag = true;
				
				}
			}
			if (!flag) {
				this.tabsearchEvent();
			}
		},
		async tabsearchEvent() {
			if (this.search === '') {
				return false;
			} else {
				let siteName = this.siteLists[this.searchNum].id;
				if (siteName == 'XT') {
					const st = await http.getSearchList(this.siteLists[this.searchNum], this.search);
					this.searchLists.push(st.data);
					this.detailLists = st.data[1];
					
				}
				if (siteName == 'APP') {
					const st = await http.appSearch(this.siteLists[this.searchNum], this.search);
					this.searchLists.push(st.data);
					this.detailLists = st.data[1];
				
				}
			}
		},
		async detailButton(item) {
			const targetHref = item[1];
			const targetImage = item[2];
			const targetTitle = item[0];
			const targetState = item[3];
			const targetName = this.nameLists[this.searchNum];
			const key = targetName + '@@' + item[1];
			const res = await db.get('notive', key);
			if (res.flag) {
				const targetStar = '../../static/star.png';
				const targetUserState = res.data.userState;
				const urll = `/pages/detail/detail?href=${targetHref}&image=${targetImage}&title=${targetTitle}&state=${targetState}&userState=${targetUserState}&name=${targetName}&star=${targetStar}`;
				uni.navigateTo({ url: urll });
			} else {
				const targetStar = '../../static/star1.png';
				const targetUserState = '无';
				const urll = `/pages/detail/detail?href=${targetHref}&image=${targetImage}&title=${targetTitle}&state=${targetState}&userState=${targetUserState}&name=${targetName}&star=${targetStar}`;

				uni.navigateTo({ url: urll });
			}
		}
	},
	onLoad: function(option) {
		this.search = option.search;
		this.getNameLists();
	
	}
};
</script>

<style lang="scss" scoped>
.search {
		margin-top: 40px;
flex: 1;
	.header {
		
			
	// 		position: sticky;
	// 		top: var(--window-top);

	// 		z-index: 999;
	
		
		
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		.header-img {
			height: 40px;
			width: 40px;
			margin-top: 2px;
			margin-left: 10px;
		}
		.search-layout {
			height: 50px;
		}
		.search-text {
			height: 50px;
			margin-top: 15px;
			font-size: 20px;
			margin-right: 20px;
		}
	}
	.body {
		margin-left: 10px;
		display: flex;
		flex-direction: row;
		justify-content: flex-start;
		.tab-item {
			margin-left: 10px;
      display: flex;
		flex-direction: column;
			margin-right: 10px;
		
			.tab-data {
				.item-title {
					margin-bottom: 20px;
					color: #000;
					font-size: 20px;
					margin-right: 5px;
				}
				.item-title-active {
					margin-bottom: 20px;
					color: #00aa00;
					font-size: 20px;
					margin-right: 5px;
				}
			}
		}
		.data-item {
	    //    position: fixed;
		   // top: 105px;
		   // left: 70px;
			margin-top: 0px;
			margin-left: 5px;
			display: flex;
			flex-direction: column;
			justify-content: flex-start;
			}
		
			
			.out-item {
				margin-bottom: 10px;
				.tui-list-item {
					display: flex;
					flex-direction: row;
					justify-content: flex-start;
					.item-img {
						height: 100px;
						width: 75px;
						margin-right: 10px;
					}
					.item-box {
						display: flex;
						flex-direction: column;
						justify-content: space-around;
					}
					.item-title {
						font-size: 20px;
					}
					.item-state {
						color: #999;
						font-size: 16px;
						display: flex;
					}
					.item-userstate {
						color: #999;
						font-size: 16px;
					}
					.item-name {
						color: #999;
						font-size: 16px;
					}
				}
			
		}
	}
}
</style>
